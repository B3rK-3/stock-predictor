import pandas as pd
import pandas_ta as pdt
import re
import torch
import os
from sklearn.preprocessing import StandardScaler, MinMaxScaler
import numpy as np
from datetime import datetime
import random
import torch.nn as nn
from ray import tune

l = re.split(r"[\\/]", os.path.abspath(os.getcwd()))
BASE_PATH = "/".join(l[:-1]) + "/"

DATA_PATH = BASE_PATH + "stock-predictor/test_data"
RESULTS_PATH = BASE_PATH + "stock-predictor/train_stock_change/results"
os.makedirs(RESULTS_PATH, exist_ok=True)  # Ensure the results directory exists


def load_data(stock_csv, min_points):
    """Loads and preprocesses data for a single Active Region (AR)."""
    try:
        read = pd.read_csv(
            f"{DATA_PATH}/{stock_csv}"
        )  # "ticker","name","date","open","high","low","close","adjusted close","volume"
        if read.shape[0] <= max(60, min_points):
            return None
        data = pd.DataFrame()
        # --- Feature Engineering ---
        # 1. Calculate indicators from RAW prices and add as new columns
        data["rsi_14"] = pdt.rsi(read["Close"], length=14)
        data["atr"] = pdt.atr(read["High"], read["Low"], read["Close"], length=14)
        macd_df = pdt.macd(read["Close"], fast=12, slow=26, signal=9)
        data["macd"] = macd_df["MACD_12_26_9"]
        data["macd_signal"] = macd_df["MACDs_12_26_9"]
        data["volume_ratio"] = read["Volume"] / read["Volume"].rolling(30).mean()

        # 2. Calculate pct_change features with NEW names
        data["open_pct"] = read["Open"].pct_change()
        data["high_pct"] = read["High"].pct_change()
        data["low_pct"] = read["Low"].pct_change()
        data["close_pct"] = read["Close"].pct_change()  # This will be our target 'y'
        bollinger = pdt.bbands(read["Close"], length=20)
        data["bb_width"] = (
            bollinger["BBU_20_2.0"] - bollinger["BBL_20_2.0"]
        ) / bollinger["BBM_20_2.0"]

        time_col_name = "timestamp" if "timestamp" in read.columns else "Datetime"
        data["timestamp"] = pd.to_datetime(read[time_col_name])

        # 4. Drop all NaNs created by indicators and pct_change
        data.dropna(inplace=True)

        """More Momentum:

    Stochastic Oscillator (%K and %D): Similar to RSI, shows overbought/oversold levels.

    pdt.stoch(data['high'], data['low'], data['close'])

Volatility:

    Bollinger Bands: Specifically, the width of the bands ((Upper - Lower) / Middle) is a great measure of volatility squeeze/expansion.

    bollinger = pdt.bbands(data['close'])

    data['bb_width'] = (bollinger['BBU_20_2.0'] - bollinger['BBL_20_2.0']) / bollinger['BBM_20_2.0']

Volume/Money Flow:

    On-Balance Volume (OBV): A classic indicator that relates price change to volume.

    pdt.obv(data['close'], data['volume'])

Time/Calendar Features:

    data['day_of_week'] = data.index.dayofweek

    data['month'] = data.index.month

    These should be one-hot encoded before being fed to the model."""

        return data
    except FileNotFoundError:
        print(f"Warning: Data file for {stock_csv} not found. Skipping.")
        return None


def prepare_dataset(stock_csv, num_in, num_pred):
    """
    Loads, processes, splits, and scales data correctly without data leakage,
    then creates sequences for both training and testing.
    """
    # Use the corrected data loading/feature engineering function from our previous discussion
    data = load_data(stock_csv, num_in + num_pred)
    if data is None:
        return None, None, None, None, None, None

    feature_columns = [
        col for col in data.columns if col != "close_pct" and col != "timestamp"
    ]
    target_column = "close_pct"
    time = data["timestamp"]

    X = data[feature_columns]
    y = data[target_column]

    train_size = int(len(data) * 0.75)

    X_train, X_test = X.iloc[:train_size], X.iloc[train_size:]
    y_train, y_test = y.iloc[:train_size], y.iloc[train_size:]
    time_test = time.iloc[train_size:]

    feature_scaler = StandardScaler()
    target_scaler = StandardScaler() # Create a SEPARATE scaler for the target

    # Fit the scalers ONLY on the training data
    X_train_scaled = feature_scaler.fit_transform(X_train)
    # Reshape y_train to be a 2D array for the scaler
    y_train = target_scaler.fit_transform(y_train.values.reshape(-1, 1))

    # Use the fitted scalers to transform the test sets
    X_test_scaled = feature_scaler.transform(X_test)
    y_test = target_scaler.transform(y_test.values.reshape(-1, 1))


    # training sequences
    x_train_seq, y_train_seq = [], []
    for i in range(len(X_train_scaled) - num_in - num_pred + 1):
        x_train_seq.append(X_train_scaled[i : i + num_in])
        y_train_seq.append(y_train.iloc[i + num_in : i + num_in + num_pred].values)

    # testing sequences
    x_test_seq, y_test_seq = [], []
    for i in range(len(X_test_scaled) - num_in - num_pred + 1):
        x_test_seq.append(X_test_scaled[i : i + num_in])
        y_test_seq.append(y_test.iloc[i + num_in : i + num_in + num_pred].values)

    X_train_tensor = np.array(x_train_seq, dtype=np.float32)
    y_train_tensor = np.array(y_train_seq, dtype=np.float32)
    X_test_tensor = np.array(x_test_seq, dtype=np.float32)
    y_test_tensor = np.array(y_test_seq, dtype=np.float32)

    return (
        X_train_tensor,
        y_train_tensor,
        X_test_tensor,
        y_test_tensor,
        time_test,
        len(feature_columns),
    )


def calculate_metrics(timeline_true, timeline_predicted):
    timeline_true = np.array(timeline_true)
    timeline_predicted = np.array(timeline_predicted)
    MAE = np.mean(np.abs(timeline_predicted - timeline_true))
    MSE = np.mean(np.square(timeline_predicted - timeline_true))
    RMSE = np.sqrt(MSE)
    RMSLE = np.sqrt(
        np.mean(np.square(np.log1p(timeline_predicted) - np.log1p(timeline_true)))
    )
    SS_res = np.sum(np.square(timeline_true - timeline_predicted))
    SS_tot = np.sum(np.square(timeline_true - np.mean(timeline_true)))
    R_squared = 1 - (SS_res / SS_tot)
    return MAE, MSE, RMSE, RMSLE, R_squared


class LSTM(nn.Module):
    def __init__(self, input_size, hidden_size, num_layers, output_length, dropout=0.0):
        super(LSTM, self).__init__()
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.output_length = output_length
        self.encoder_lstm = nn.LSTM(
            input_size, hidden_size, num_layers, batch_first=True, dropout=dropout
        )
        self.decoder_lstm = nn.LSTM(
            1, hidden_size, num_layers, batch_first=True, dropout=dropout
        )

        self.decoder_fc = nn.Linear(hidden_size, 1)

    def forward(self, x, y=None, teacher_forcing_ratio=0.5):
        _, (hidden, cell) = self.encoder_lstm(x)

        decoder_input = torch.zeros(x.size(0), 1, 1).to(x.device)
        outputs = []

        for t in range(self.output_length):
            out_dec, (hidden, cell) = self.decoder_lstm(decoder_input, (hidden, cell))
            out = self.decoder_fc(out_dec)
            outputs.append(out)

            # Decide whether to use teacher forcing for the next step
            use_teacher_forcing = (y is not None) and (
                random.random() < teacher_forcing_ratio
            )

            if use_teacher_forcing:
                # Use the actual ground-truth value as the next input
                decoder_input = y[:, t].unsqueeze(1).unsqueeze(1)
            else:
                # Use the model's own prediction as the next input
                decoder_input = out

        outputs = torch.cat(outputs, dim=1).squeeze(-1)
        return outputs


class VanillaLSTM(nn.Module):
    def __init__(self, input_size, hidden_size, num_layers, output_length, dropout=0.0):
        super(VanillaLSTM, self).__init__()

        # A single LSTM layer that processes the entire input sequence
        self.lstm = nn.LSTM(
            input_size=input_size,
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=True,  # Input tensor shape: [batch_size, seq_length, input_size]
            dropout=dropout,
        )

        # A single linear layer to map the final LSTM state to the desired output length
        self.fc = nn.Linear(hidden_size, output_length)

    def forward(self, x):
        # Pass the input sequence through the LSTM layer
        # We don't need the final hidden and cell states, just the output sequence
        lstm_out, _ = self.lstm(x)

        # We only need the output from the very last time step of the sequence
        # lstm_out has shape [batch_size, seq_length, hidden_size]
        # We take the last time step: lstm_out[:, -1, :]
        last_time_step_out = lstm_out[:, -1, :]

        # Pass the last time step's output to the linear layer to get the final prediction
        prediction = self.fc(last_time_step_out)

        return prediction


class PlateauStopper(tune.stopper.Stopper):
    """Stops trials when the metric has plateaued."""

    def __init__(
        self,
        metric: str,
        min_epochs: int = 20,
        patience: int = 10,
        min_improvement_percent: float = 1e-5,
    ):
        """
        Args:
            metric: The metric to monitor.
            min_epochs: Minimum number of epochs to run before stopping is considered.
            patience: Number of recent epochs to check for improvement.
            min_improvement: The minimum improvement required to not stop the trial.
        """
        self._metrics = metric
        self._min_epochs = min_epochs
        self._patience = patience
        self._min_improvement = min_improvement_percent
        self._trial_history = {}  # To store the history of each trial

    def __call__(self, trial_id: str, result: dict) -> bool:
        """This is called after each tune.report() call."""
        # Initialize history for a new trial
        if trial_id not in self._trial_history:
            self._trial_history[trial_id] = []

        history = self._trial_history[trial_id]
        history.append(result[self._metrics])

        # Don't stop if we haven't reached the minimum number of epochs
        if len(history) <= self._min_epochs:
            return False

        # Check for improvement over the patience window
        # We look at the best value in the last `patience` epochs
        # and compare it to the best value before that window.
        window = history[-self._patience :]
        previous_best = min(history[: -self._patience])
        current_best = min(window)

        # If there's no meaningful improvement, stop the trial
        improvement_needed = previous_best * self._min_improvement / 100
        if previous_best - current_best < improvement_needed:
            print(
                f"Stopping trial {trial_id}: "
                f"No improvement of {improvement_needed} in the last {self._patience} epochs."
            )
            return True

        return False

    def stop_all(self) -> bool:
        """This function is used to stop all trials at once. We don't need it here."""
        return False
