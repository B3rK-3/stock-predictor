# stock-predictor

Put stock data in .csv format with at leat columns time/timestamp, open, close, high, low

- run the preprocess_data.py with python preprocess_data.py
    - you will see stock_data.npz and stock_data_eval.npz
        these two will be used for train-validation and evaluation respectively 

train_stcok_price folder is for individual stock training and making models

train_stock_change is for general stock training
    - running this will take a while

